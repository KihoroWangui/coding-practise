<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8>"
    <meta http-equiv="X-UA-Compactible"content="IE=edge>"
   <meta name="viewport"content="width=device-width, initial-scale=1.0>"
   <title>fashion botique</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
<link rel="stylesheet" href="style.css" />
    <style>
      body {
        background-color: rgb(243, 241, 241);
      }
      h1 {
        color: black;
        font-size: 2.5rem;
        font-weight:700;
        font-family:"castellar";
        margin-left: 20px;
      }
      .navbar-light .navbar-nav .nav-link{
  padding:0 20px;
  color:black;
  transition:0.3s ease;
}
.navbar-light .navbar-nav .nav-link:hover,
.navbar i:hover,
.navbar-light .navbar-nav .nav-link.active,
.navbar i.active{
color:crimson;
}
.navbar i{
  font-size:1.2rem;
  padding:0 7px;
  cursor:pointer;
  font-weight:500;
  transition:0.3s ease;
      }
    </style>
  </head>
  <body>
    <!--NAVIGATION-->
    <nav class="navbar navbar-expand-lg navbar-light bg-light py-3 fixed-top">
      <div class="container">
        <h1>GUARDIAN CARE</h1>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span><i id="bar" class="fas fa-bars"></i></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="home.blade.php">Home</a>
            </li>
            <li class="nav item">
              <a class="nav-link" href="shop page.html">Mood Tracker</a>
            </li>
             <li class="nav-item">
              <a class="nav-link" href="blog page.html">Donations</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="about.page.html">Respite-Centers</a>
            </li>
            
            <li class="nav-item">
              <a class="nav-link" href="login.blade.php">Login</a>
            </li>
        </div>
      </div>
    </nav>
    <div style="border: 3px solid  black;">
  <h2>Register</h2>
  <form action="/register" method="POST">
  <input type="hidden" name="_token" value="{{ csrf_token() }}">
    <input name="name" type="text" placeholder="name">
    <input name="email" type="text" placeholder="email">
    <input name="password" type="password" placeholder="password">
    <button>Register</button>
  </form>
</body>
</html>
