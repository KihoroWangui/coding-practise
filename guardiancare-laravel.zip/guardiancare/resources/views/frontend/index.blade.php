@extends('layout.frontend');

@section('title')
GuardianCare
@endsection

@section('content')
<div class= "container">
    <div class="row">
    <div class="col-md-12 text-center">
        <h1>Welcome to GuardianCare</h1>
</div>
</div>
</div>
@endsection

@endsection('scripts')
@endsection
