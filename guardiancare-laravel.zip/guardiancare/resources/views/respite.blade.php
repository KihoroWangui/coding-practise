<!DOCTYPE html>
<html>
<head>
  <title>GuardianCare</title>
  <style>
    /* CSS styles for the navigation bar */
    ul.navbar {
      list-style-type: none;
      margin: 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
    }

    ul.navbar li {
      float: left;
    }

    ul.navbar li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }

    ul.navbar li a:hover {
      background-color: #111;
    }

    /* CSS styles for the logo */
    div.logo {
      text-align: center;
      padding: 20px;
    }

    div.logo img {
      width: 200px;
      height: 200px;
    }
  </style>
</head>
<body>
  <div class="logo">
    <img src="C:\Users\user\fashion botique\img folder\download.jpg" alt="Logo">
  </div>

  <ul class="navbar">
    <li><a href="#">Home</a></li>
    <li><a href="#">About</a></li>
    <li><a href="#">Services</a></li>
    <li><a href="#">Contact</a></li>
    
  </ul>
</body>
</html>
