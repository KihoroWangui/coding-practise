<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RespiteCenterController extends Controller
{
    //
}
