<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MentalHealthResourceController extends Controller
{
    //
}
